﻿using NAudio;
using NAudio.Wave;

using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace musicPlayer
{

	public class Beeper
	{

		/// ***************************** CONSTUCTOR ********************************

		public Beeper(string key, string script, double bpm, double volume = 1000)
		{
			Volume = volume;

			CreateStream();

			string letters = "ABCDEFGA";
			if (key.Length > 2 && key[1] == '#' && letters.IndexOf(key[0]) >= 0)
				key = letters[letters.IndexOf(key[0]) + 1].ToString() + "b" + key[2].ToString();

			if (script.Length > 2 && script[0] == '@')
			{
				string settings = script.Substring(1, script.IndexOf(' ') - 1);
				script = script.Substring(settings.Length + 1);

				foreach (char p in settings)
				{
					if (p == '-')
						key = key.Substring(0, key.Length - 1) + (int.Parse(key[key.Length - 1].ToString()) - 1);
					else if (p == '+')
						key = key.Substring(0, key.Length - 1) + (int.Parse(key[key.Length - 1].ToString()) + 1);
					else
						throw new InvalidCastException();
				}
			}

			double mainFrequency = Note.frequencyOf[key];
			int mainIndex = Note.frequencies.IndexOf(mainFrequency);
			int[] toneIndices = { mainIndex, mainIndex + 2, mainIndex + 4, mainIndex + 5, mainIndex + 7, mainIndex + 9, mainIndex + 11 };

			Dictionary<char, double> durationOf = GetBeatDurations(bpm);

			string[] notes = script.Replace("\r", "").Replace("\n", "").Split(' ');

			double durationDecimal = 0;

			foreach (string p in notes)
			{
				try
				{
					if (p == "")
						continue;

					//tra.ce(p);

					int note = -1;

					if (int.TryParse(p.Substring(0, 1), out note))
					{
						int noteIndex = toneIndices[int.Parse(p[0].ToString()) - 1];
						int specIndex = 0;
						char noteType = '/';
						double duration = 0;
						double tempDur = 0;
						//bool hasPoM = p.Length > 1 && (p[1] == '+' || p[1] == '-');

						for (int i = 1, l = p.Length; i < l; i++)
						{
							if (p[i] == '+')
								noteIndex += 12;
							else if (p[i] == '-')
								noteIndex -= 12;
							else if (p[i] == 'b')
								specIndex--;
							else if (p[i] == '#')
								specIndex++;
							else if (durationOf.ContainsKey(p[i]))
							{
								noteType = p[i];
								tempDur = durationOf[noteType];

								if (i < l - 1 && p[i + 1] == '.')
								{
									tempDur *= 1.5;
									i++;
								}

								duration += tempDur;
							}
							else if (p[i] == '.')
							{
								duration += tempDur = durationOf['/'] * 1.5;
							}
							else if (p[i] == '~')
							{
								if (noteType == '/' && tempDur == 0)
									duration += durationOf['/'];

								noteType = '/';
								tempDur = 0;
							}
							else
								throw new InvalidExpressionException();
						}

						if (noteType == '/' && tempDur == 0)
							duration += durationOf['/'];

						double freq = Note.frequencies[noteIndex + specIndex];
						int intfreq = (int)Math.Round(freq, 0);
						int intdur = (int)duration + (int)durationDecimal;

						durationDecimal += duration % 1;

						//tra.ce(freq, dec, duration, (int)duration + (int)dec);

						//be.ep(freq, intdur, vol);
						//Thread.Sleep(intdur);
						AddNote(freq, intdur);

						//outputs.Add($"Console.Beep({intfreq}, {intdur});");

						durationDecimal %= 1;
					}
					else
					{
						//tra.ce("REST");

						double duration = durationOf[p[0]];

						durationDecimal += duration % 1;

						int intdur = (int)duration + (int)durationDecimal;

						AddNote(0, intdur);

						//Thread.Sleep((int)duration + (int)durationDecimal);
						//outputs.Add($"Thread.Sleep({(int)duration + (int)durationDecimal});");

						durationDecimal %= 1;
					}
				} // end try
				catch (Exception ee)
				{
					if (!(ee is ThreadAbortException))
						MessageBox.Show($"GET OUTTA HERE WITH DAT {ee.GetType().ToString().Split('.').Reverse().ToList()[0]} AT NOTE \"{p}\"!!", "Oops!");
				}
			} // end for

			Stream.Seek(0, SeekOrigin.Begin);
		}

		/// ************************** PUBLIC PROPERTIES ****************************

		public BinaryWriter BinaryWriter;
		public MemoryStream Stream;
		public WaveOut Sound;
		public double Volume;
		public bool IsPlaying;
		public bool IsLooping;

		/// ************************* PRIVATE PROPERTIES ****************************


		/// *************************** PUBLIC METHODS ******************************

		public void Play(bool looping = false)
		{
			WaveOut sound = new WaveOut(WaveCallbackInfo.FunctionCallback());
			sound.Init(new WaveFileReader(Stream));

			sound.PlaybackStopped += OnSoundPlayBackStopped;

			IsLooping = looping;

			sound.Play();

			IsPlaying = true;
		}

		public void Stop()
		{
			IsPlaying = false;

			if (Sound == null || Sound.PlaybackState != PlaybackState.Playing)
				return;

			Sound.Stop();

			Sound.PlaybackStopped -= OnSoundPlayBackStopped;

			Sound.Dispose();

			IsLooping = false;
			Sound = null;
		}

		/// *************************** PRIVATE METHODS *****************************

		protected Dictionary<char, double> GetBeatDurations(double bpm)
		{
			Dictionary<char, double> durationOf = new Dictionary<char, double>();

			double quarter = 60000 / bpm;
			double half = quarter * 2;
			double whole = half * 2;
			double eighth = quarter / 2;
			double sixteenth = eighth / 2;
			double thirtysecond = sixteenth / 2;

			durationOf['o'] = whole;
			durationOf['d'] = half;
			durationOf['/'] = quarter;
			durationOf['\''] = eighth;
			durationOf['g'] = eighth;
			durationOf['\"'] = sixteenth;
			durationOf['j'] = sixteenth;
			durationOf['`'] = thirtysecond;

			return durationOf;
		}

		protected void CreateStream()
		{
			int bytes = 441 * 999999 / 10 * 4;
			int[] hdr = { 0X46464952, 36 + bytes, 0X45564157, 0X20746D66, 16, 0X20001, 44100, 176400, 0X100004, 0X61746164, bytes };

			Stream = new MemoryStream();

			BinaryWriter = new BinaryWriter(Stream);

			foreach (int p in hdr)
			{
				BinaryWriter.Write(p);
			}

			BinaryWriter.Flush();
		}

		protected void AddNote(double frequency, int duration)
		{
			double amp = ((Volume * (System.Math.Pow(2, 15))) / 1000) - 1;
			double deltaFt = 2 * Math.PI * frequency / 44100.0;

			int Samples = 441 * duration / 10;

			for (int i = 0; i < Samples; i++)
			{
				short s = Convert.ToInt16(amp * Math.Sin(deltaFt * i));
				BinaryWriter.Write(s);
				BinaryWriter.Write(s);
			}

			BinaryWriter.Flush();
		}

		/// ******************************* EVENTS **********************************

		private void OnSoundPlayBackStopped(object sender, StoppedEventArgs e)
		{
			if (IsLooping)
			{
				Sound.Play();
			}
			else
			{
				Stop();

				IsPlaying = false;
			}
		}

	}

}
