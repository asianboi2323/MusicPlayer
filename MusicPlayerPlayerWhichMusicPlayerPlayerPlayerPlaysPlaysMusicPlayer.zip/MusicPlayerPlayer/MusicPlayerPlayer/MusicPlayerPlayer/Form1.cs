﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Diagnostics;
using TestStack.White.Factory;
using TestStack.White.UIItems.WindowItems;
using System.IO;
using System.Threading;

namespace MusicPlayerPlayer
{
    public partial class Form1 : Form
    {
        List<TestStack.White.Application> apps;

        protected string url = @"Quack.mp3";

        public Form1()
        {
            apps = new List<TestStack.White.Application>();
            InitializeComponent();

            //button1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            long time = (long)t.TotalMilliseconds;

            if (!File.Exists(url))
                File.CreateText(url).Close();

            File.WriteAllText(url, (time + (numericUpDownWindows.Value * 833)).ToString());


            foreach (TestStack.White.Application app in apps)
            {
                try
                {
                    Window window = app.GetWindow("Form1", InitializeOption.NoCache);
                    window.
                    TestStack.White.UIItems.Button button = window.Get<TestStack.White.UIItems.Button>("button1");
                    new Thread(() =>
                    {
                        button.Click();
                    }).Start();
                }
                catch (Exception) { }
            }

        }

        protected void onFormClose(object sender, FormClosingEventArgs e)
        {
            foreach (TestStack.White.Application app in apps)
            {
                try
                {
                    app.Close();
                }
                catch (Exception)
                {
                    MessageBox.Show("GET OUTTA HERE WITH DAT OPENED FILE!!!");
                }

                File.Delete(url);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (TestStack.White.Application app in apps)
            {
                try
                {

                    Window window = app.GetWindow("Form1", InitializeOption.NoCache);

                    TestStack.White.UIItems.Button button = window.Get<TestStack.White.UIItems.Button>("stopbutton");
                    button.Click();
                }
                catch (Exception) { }
            }
        }

        private void numericUpDownWindows_ValueChanged(object sender, EventArgs e)
        {
            if (((NumericUpDown)sender).Value < apps.Count)
            {
                apps[apps.Count - 1].Close();
                apps.RemoveAt(apps.Count - 1);
            }else if (((NumericUpDown)sender).Value > apps.Count)
            {
                apps.Add(TestStack.White.Application.Launch("musicPlayer.exe"));
            }

        }
    }
}
