﻿namespace musicPlayer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.button1 = new System.Windows.Forms.Button();
			this.txtkey = new System.Windows.Forms.TextBox();
			this.txtbpm = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.crep = new System.Windows.Forms.CheckBox();
			this.stopbutton = new System.Windows.Forms.Button();
			this.list = new System.Windows.Forms.ListBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtname = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btnnew = new System.Windows.Forms.Button();
			this.bdel = new System.Windows.Forms.Button();
			this.bsave = new System.Windows.Forms.Button();
			this.btnhelp = new System.Windows.Forms.Button();
			this.cbadv = new System.Windows.Forms.CheckBox();
			this.bref = new System.Windows.Forms.Button();
			this.boutput = new System.Windows.Forms.Button();
			this.txtscript = new System.Windows.Forms.RichTextBox();
			this.txtdelay = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.cbdelay = new System.Windows.Forms.CheckBox();
			this.cbpot = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(645, 377);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(143, 70);
			this.button1.TabIndex = 1;
			this.button1.Text = "Play";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtkey
			// 
			this.txtkey.Location = new System.Drawing.Point(322, 352);
			this.txtkey.Name = "txtkey";
			this.txtkey.Size = new System.Drawing.Size(83, 25);
			this.txtkey.TabIndex = 12;
			this.txtkey.Text = "C5";
			// 
			// txtbpm
			// 
			this.txtbpm.Location = new System.Drawing.Point(322, 387);
			this.txtbpm.Name = "txtbpm";
			this.txtbpm.Size = new System.Drawing.Size(83, 25);
			this.txtbpm.TabIndex = 13;
			this.txtbpm.Text = "120";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(267, 390);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(45, 17);
			this.label1.TabIndex = 4;
			this.label1.Text = "BPM:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(269, 355);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(38, 17);
			this.label2.TabIndex = 5;
			this.label2.Text = "Key:";
			// 
			// crep
			// 
			this.crep.AutoSize = true;
			this.crep.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.crep.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.crep.Location = new System.Drawing.Point(428, 350);
			this.crep.Name = "crep";
			this.crep.Size = new System.Drawing.Size(80, 22);
			this.crep.TabIndex = 15;
			this.crep.Text = "Repeat";
			this.crep.UseVisualStyleBackColor = true;
			// 
			// stopbutton
			// 
			this.stopbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.stopbutton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.stopbutton.Location = new System.Drawing.Point(645, 453);
			this.stopbutton.Name = "stopbutton";
			this.stopbutton.Size = new System.Drawing.Size(143, 29);
			this.stopbutton.TabIndex = 0;
			this.stopbutton.Text = "Stop";
			this.stopbutton.UseVisualStyleBackColor = true;
			this.stopbutton.Click += new System.EventHandler(this.onstopclick);
			// 
			// list
			// 
			this.list.FormattingEnabled = true;
			this.list.ItemHeight = 17;
			this.list.Location = new System.Drawing.Point(15, 33);
			this.list.Name = "list";
			this.list.Size = new System.Drawing.Size(222, 344);
			this.list.TabIndex = 3;
			this.list.SelectedIndexChanged += new System.EventHandler(this.list_SelectedIndexChanged);
			this.list.KeyDown += new System.Windows.Forms.KeyEventHandler(this.list_KeyDown);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
			this.label3.Location = new System.Drawing.Point(13, 13);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(106, 17);
			this.label3.TabIndex = 4;
			this.label3.Text = "Saved Musics:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
			this.label4.Location = new System.Drawing.Point(264, 61);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(50, 17);
			this.label4.TabIndex = 5;
			this.label4.Text = "Script:";
			// 
			// txtname
			// 
			this.txtname.Location = new System.Drawing.Point(267, 33);
			this.txtname.Name = "txtname";
			this.txtname.Size = new System.Drawing.Size(521, 25);
			this.txtname.TabIndex = 10;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
			this.label5.Location = new System.Drawing.Point(264, 13);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(52, 17);
			this.label5.TabIndex = 5;
			this.label5.Text = "Name:";
			// 
			// btnnew
			// 
			this.btnnew.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnnew.Location = new System.Drawing.Point(128, 384);
			this.btnnew.Name = "btnnew";
			this.btnnew.Size = new System.Drawing.Size(109, 29);
			this.btnnew.TabIndex = 5;
			this.btnnew.Text = "New";
			this.btnnew.UseVisualStyleBackColor = true;
			this.btnnew.Click += new System.EventHandler(this.btnnew_Click);
			// 
			// bdel
			// 
			this.bdel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bdel.Location = new System.Drawing.Point(13, 419);
			this.bdel.Name = "bdel";
			this.bdel.Size = new System.Drawing.Size(109, 29);
			this.bdel.TabIndex = 6;
			this.bdel.Text = "Delete";
			this.bdel.UseVisualStyleBackColor = true;
			this.bdel.Click += new System.EventHandler(this.bdel_Click);
			// 
			// bsave
			// 
			this.bsave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bsave.Location = new System.Drawing.Point(128, 419);
			this.bsave.Name = "bsave";
			this.bsave.Size = new System.Drawing.Size(109, 29);
			this.bsave.TabIndex = 7;
			this.bsave.Text = "Save";
			this.bsave.UseVisualStyleBackColor = true;
			this.bsave.Click += new System.EventHandler(this.bsave_Click);
			// 
			// btnhelp
			// 
			this.btnhelp.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnhelp.Location = new System.Drawing.Point(13, 384);
			this.btnhelp.Name = "btnhelp";
			this.btnhelp.Size = new System.Drawing.Size(109, 29);
			this.btnhelp.TabIndex = 4;
			this.btnhelp.Text = "Help";
			this.btnhelp.UseVisualStyleBackColor = true;
			this.btnhelp.Click += new System.EventHandler(this.btnhelp_Click);
			// 
			// cbadv
			// 
			this.cbadv.AutoSize = true;
			this.cbadv.Checked = true;
			this.cbadv.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbadv.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cbadv.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbadv.Location = new System.Drawing.Point(428, 385);
			this.cbadv.Name = "cbadv";
			this.cbadv.Size = new System.Drawing.Size(145, 22);
			this.cbadv.TabIndex = 16;
			this.cbadv.Text = "Advanced Beeps";
			this.cbadv.UseVisualStyleBackColor = true;
			// 
			// bref
			// 
			this.bref.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bref.Location = new System.Drawing.Point(13, 454);
			this.bref.Name = "bref";
			this.bref.Size = new System.Drawing.Size(109, 29);
			this.bref.TabIndex = 8;
			this.bref.Text = "Refresh";
			this.bref.UseVisualStyleBackColor = true;
			this.bref.Click += new System.EventHandler(this.bref_Click);
			// 
			// boutput
			// 
			this.boutput.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.boutput.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.boutput.Location = new System.Drawing.Point(128, 454);
			this.boutput.Name = "boutput";
			this.boutput.Size = new System.Drawing.Size(109, 29);
			this.boutput.TabIndex = 9;
			this.boutput.Text = "Output as Code";
			this.boutput.UseVisualStyleBackColor = true;
			this.boutput.Click += new System.EventHandler(this.onoutput);
			// 
			// txtscript
			// 
			this.txtscript.Location = new System.Drawing.Point(267, 81);
			this.txtscript.Name = "txtscript";
			this.txtscript.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
			this.txtscript.Size = new System.Drawing.Size(521, 253);
			this.txtscript.TabIndex = 11;
			this.txtscript.Text = "";
			// 
			// txtdelay
			// 
			this.txtdelay.Location = new System.Drawing.Point(322, 422);
			this.txtdelay.Name = "txtdelay";
			this.txtdelay.Size = new System.Drawing.Size(83, 25);
			this.txtdelay.TabIndex = 14;
			this.txtdelay.Text = "0";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(267, 425);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(50, 17);
			this.label6.TabIndex = 4;
			this.label6.Text = "Delay:";
			// 
			// cbdelay
			// 
			this.cbdelay.AutoSize = true;
			this.cbdelay.Checked = true;
			this.cbdelay.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbdelay.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cbdelay.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbdelay.Location = new System.Drawing.Point(428, 420);
			this.cbdelay.Name = "cbdelay";
			this.cbdelay.Size = new System.Drawing.Size(158, 22);
			this.cbdelay.TabIndex = 17;
			this.cbdelay.Text = "Play Delay Sounds";
			this.cbdelay.UseVisualStyleBackColor = true;
			// 
			// cbpot
			// 
			this.cbpot.AutoSize = true;
			this.cbpot.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cbpot.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cbpot.Location = new System.Drawing.Point(428, 454);
			this.cbpot.Name = "cbpot";
			this.cbpot.Size = new System.Drawing.Size(102, 22);
			this.cbpot.TabIndex = 18;
			this.cbpot.Text = "Pin on Top";
			this.cbpot.UseVisualStyleBackColor = true;
			this.cbpot.CheckedChanged += new System.EventHandler(this.cbpot_CheckedChanged);
			// 
			// Form1
			// 
			this.AcceptButton = this.button1;
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.stopbutton;
			this.ClientSize = new System.Drawing.Size(799, 492);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.list);
			this.Controls.Add(this.txtscript);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.cbpot);
			this.Controls.Add(this.cbdelay);
			this.Controls.Add(this.cbadv);
			this.Controls.Add(this.crep);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtdelay);
			this.Controls.Add(this.txtbpm);
			this.Controls.Add(this.txtkey);
			this.Controls.Add(this.boutput);
			this.Controls.Add(this.bref);
			this.Controls.Add(this.bsave);
			this.Controls.Add(this.bdel);
			this.Controls.Add(this.btnhelp);
			this.Controls.Add(this.btnnew);
			this.Controls.Add(this.stopbutton);
			this.Controls.Add(this.txtname);
			this.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtkey;
        private System.Windows.Forms.TextBox txtbpm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox crep;
		private System.Windows.Forms.Button stopbutton;
		private System.Windows.Forms.ListBox list;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtname;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnnew;
		private System.Windows.Forms.Button bdel;
		private System.Windows.Forms.Button bsave;
		private System.Windows.Forms.Button btnhelp;
		private System.Windows.Forms.CheckBox cbadv;
		private System.Windows.Forms.Button bref;
		private System.Windows.Forms.Button boutput;
		private System.Windows.Forms.RichTextBox txtscript;
		private System.Windows.Forms.TextBox txtdelay;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.CheckBox cbdelay;
		private System.Windows.Forms.CheckBox cbpot;
	}
}

