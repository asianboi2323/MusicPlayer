﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Security.Permissions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace musicPlayer
{

	public partial class Form1 : Form
	{

		public Form1()
		{
			InitializeComponent();

			//TopMost = true;

			noteArray = new double[] { 31609, 29834, 28160, 26580, 25088, 23680, 22351, 21096, 19912, 18795, 17740, 16744, 15804, 14917, 14080, 13290, 12544, 11840, 11175, 10548, 9956, 9397, 8870, 8372, 7902.13, 7458.62, 7040, 6644.88, 6271.93, 5919.91, 5587.65, 5274.04, 4978.03, 4698.63, 4434.92, 4186.01, 3951.07, 3729.31, 3520, 3322.44, 3135.96, 2959.96, 2793.83, 2637.02, 2489.02, 2349.32, 2217.46, 2093,
				1975.53, 1864.66, 1760, 1661.22, 1567.98, 1479.98, 1396.91, 1318.51, 1244.51, 1174.66, 1108.73, 1046.5, 987.77, 932.33, 880, 830.61, 783.99, 739.99, 698.46, 659.25, 622.25, 587.33, 554.37, 523.25, 493.88, 466.16, 440, 415.3, 392, 369.99, 349.23, 329.63, 311.13, 293.66, 277.18, 261.63, 246.94, 233.08, 220, 207.65, 196, 185, 174.61, 164.81, 155.56, 146.83, 138.59, 130.81, 123.47, 116.54, 110, 103.83, 98, 92.5, 87.31, 82.41, 77.78, 73.42, 69.3, 65.41, 61.74, 58.27, 55, 51.91, 49, 46.25, 43.65, 41.2, 38.89, };

			noteDict = new Dictionary<string, double>();
			noteDict.Add("B10", 31609); noteDict.Add("Bb10", 29834); noteDict.Add("A10", 28160); noteDict.Add("Ab10", 26580); noteDict.Add("G10", 25088); noteDict.Add("Gb10", 23680); noteDict.Add("F10", 22351); noteDict.Add("E10", 21096); noteDict.Add("Eb10", 19912); noteDict.Add("D10", 18795); noteDict.Add("Db10", 17740); noteDict.Add("C10", 16744); noteDict.Add("B9", 15804); noteDict.Add("Bb9", 14917); noteDict.Add("A9", 14080); noteDict.Add("Ab9", 13290); noteDict.Add("G9", 12544); noteDict.Add("Gb9", 11840); noteDict.Add("F9", 11175);
			noteDict.Add("E9", 10548); noteDict.Add("Eb9", 9956); noteDict.Add("D9", 9397); noteDict.Add("Db9", 8870); noteDict.Add("C9", 8372); noteDict.Add("B8", 7902.13); noteDict.Add("Bb8", 7458.62); noteDict.Add("A8", 7040); noteDict.Add("Ab8", 6644.88); noteDict.Add("G8", 6271.93); noteDict.Add("Gb8", 5919.91); noteDict.Add("F8", 5587.65); noteDict.Add("E8", 5274.04); noteDict.Add("Eb8", 4978.03); noteDict.Add("D8", 4698.63); noteDict.Add("Db8", 4434.92); noteDict.Add("C8", 4186.01); noteDict.Add("B7", 3951.07); noteDict.Add("Bb7", 3729.31);
			noteDict.Add("A7", 3520); noteDict.Add("Ab7", 3322.44); noteDict.Add("G7", 3135.96); noteDict.Add("Gb7", 2959.96); noteDict.Add("F7", 2793.83); noteDict.Add("E7", 2637.02); noteDict.Add("Eb7", 2489.02); noteDict.Add("D7", 2349.32); noteDict.Add("Db7", 2217.46); noteDict.Add("C7", 2093); noteDict.Add("B6", 1975.53); noteDict.Add("Bb6", 1864.66); noteDict.Add("A6", 1760); noteDict.Add("Ab6", 1661.22); noteDict.Add("G6", 1567.98); noteDict.Add("Gb6", 1479.98); noteDict.Add("F6", 1396.91); noteDict.Add("E6", 1318.51); noteDict.Add("Eb6", 1244.51);
			noteDict.Add("D6", 1174.66); noteDict.Add("Db6", 1108.73); noteDict.Add("C6", 1046.5); noteDict.Add("B5", 987.77); noteDict.Add("Bb5", 932.33); noteDict.Add("A5", 880); noteDict.Add("Ab5", 830.61); noteDict.Add("G5", 783.99); noteDict.Add("Gb5", 739.99); noteDict.Add("F5", 698.46); noteDict.Add("E5", 659.25); noteDict.Add("Eb5", 622.25); noteDict.Add("D5", 587.33); noteDict.Add("Db5", 554.37); noteDict.Add("C5", 523.25); noteDict.Add("B4", 493.88); noteDict.Add("Bb4", 466.16); noteDict.Add("A4", 440); noteDict.Add("Ab4", 415.3);
			noteDict.Add("G4", 392); noteDict.Add("Gb4", 369.99); noteDict.Add("F4", 349.23); noteDict.Add("E4", 329.63); noteDict.Add("Eb4", 311.13); noteDict.Add("D4", 293.66); noteDict.Add("Db4", 277.18); noteDict.Add("C4", 261.63); noteDict.Add("B3", 246.94); noteDict.Add("Bb3", 233.08); noteDict.Add("A3", 220); noteDict.Add("Ab3", 207.65); noteDict.Add("G3", 196); noteDict.Add("Gb3", 185); noteDict.Add("F3", 174.61); noteDict.Add("E3", 164.81); noteDict.Add("Eb3", 155.56); noteDict.Add("D3", 146.83); noteDict.Add("Db3", 138.59); noteDict.Add("C3", 130.81);
			noteDict.Add("B2", 123.47); noteDict.Add("Bb2", 116.54); noteDict.Add("A2", 110); noteDict.Add("Ab2", 103.83); noteDict.Add("G2", 98); noteDict.Add("Gb2", 92.5); noteDict.Add("F2", 87.31); noteDict.Add("E2", 82.41); noteDict.Add("Eb2", 77.78); noteDict.Add("D2", 73.42); noteDict.Add("Db2", 69.3); noteDict.Add("C2", 65.41); noteDict.Add("B1", 61.74); noteDict.Add("Bb1", 58.27); noteDict.Add("A1", 55); noteDict.Add("Ab1", 51.91); noteDict.Add("G1", 49); noteDict.Add("Gb1", 46.25); noteDict.Add("F1", 43.65); noteDict.Add("E1", 41.2); noteDict.Add("Eb1", 38.89);

			threads = new List<Thread>();
			musics = new List<Music>();
			outputs = new List<string>();

			LoadBeeeeeeps();

			list.SelectedIndex = 0;
			button1.Select();
		}

		public Dictionary<string, double> noteDict;

		public double[] noteArray;

		public List<Thread> threads;
		public List<Music> musics;
		public List<string> outputs;

		private Dictionary<char, double> updateBeat(double bpm)
		{
			Dictionary<char, double> durationDict = new Dictionary<char, double>();

			double quarter = 60000 / bpm;
			double half = quarter * 2;
			double whole = half * 2;
			double eighth = quarter / 2;
			double sixteenth = eighth / 2;
			double thirtysecond = sixteenth / 2;

			durationDict['o'] = whole;
			durationDict['d'] = half;
			durationDict['╥'] = quarter;
			durationDict['/'] = quarter;
			durationDict['\''] = eighth;
			durationDict['g'] = eighth;
			durationDict['\"'] = sixteenth;
			durationDict['j'] = sixteenth;
			durationDict['`'] = thirtysecond;

			return durationDict;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			//ddd.AppendText(textBoxNotes.Text + "\n");

			bool advanced = cbadv.Checked;

			outputs.Clear();

			try
			{
				string script = txtscript.Text;

				int delay = int.Parse(txtdelay.Text);
				for (int i = 0; i < delay; i++)
					script = (cbdelay.Checked ? "1" : "") + "` ` \" ' " + script;

				string keyString = txtkey.Text;
				string beatpm = txtbpm.Text;

				string letters = "ABCDEFGA";
				if (keyString.Length > 2 && keyString[1] == '#' && letters.IndexOf(keyString[0]) >= 0)
					keyString = letters[letters.IndexOf(keyString[0]) + 1].ToString() + "b" + keyString[2].ToString();

				double keyValue = noteDict[keyString];
				int indexOfKey = Array.IndexOf(noteArray, keyValue);
				int[] notesInKey = new int[] { indexOfKey, indexOfKey - 2, indexOfKey - 4, indexOfKey - 5, indexOfKey - 7, indexOfKey - 9, indexOfKey - 11 };
				List<string> notes = script.Replace("\r", "").Replace("\n", "").Split(' ').ToList();

				Dictionary<char, double> durationDict = updateBeat(double.Parse(txtbpm.Text));

				Thread beeeeep = new Thread(() =>
				{
					double dec = 0;

					do
					{
						foreach (string p in notes)
						{
							try
							{
								if (p == "")
									continue;

								//tra.ce(p);

								int note = -1;

								if (int.TryParse(p.Substring(0, 1), out note))
								{
									int noteIndex = notesInKey[int.Parse(p[0].ToString()) - 1];
									int specIndex = 0;
									char noteType = '╥';
									double duration = 0;
									double tempDur = 0;
									//bool hasPoM = p.Length > 1 && (p[1] == '+' || p[1] == '-');

									for (int i = 1, l = p.Length; i < l; i++)
									{
										if (p[i] == '+')
											noteIndex -= 12;
										else if (p[i] == '-')
											noteIndex += 12;
										else if (p[i] == 'b')
											specIndex++;
										else if (p[i] == '#')
											specIndex--;
										else if (durationDict.ContainsKey(p[i]))
										{
											noteType = p[i];
											tempDur = durationDict[noteType];

											if (i < l - 1 && p[i + 1] == '.')
											{
												tempDur *= 1.5;
												i++;
											}

											duration += tempDur;
										}
										else if (p[i] == '.')
										{
											duration += tempDur = durationDict['╥'] * 1.5;
										}
										else if (p[i] == '~')
										{
											if (noteType == '╥' && tempDur == 0)
												duration += durationDict['╥'];

											noteType = '╥';
											tempDur = 0;
										}
										else
											throw new InvalidExpressionException();
									}

									if (noteType == '╥' && tempDur == 0)
										duration += durationDict['╥'];

									double freq = noteArray[noteIndex + specIndex];
									int intfreq = (int)Math.Round(freq, 0);
									int intdur = (int)duration + (int)dec;

									dec += duration % 1;

									//tra.ce(freq, dec, duration, (int)duration + (int)dec);

									if (advanced)
									{
										be.ep(freq, intdur);
										Thread.Sleep(intdur);
									}
									else
									{
										Console.Beep(intfreq, intdur);
									}

									outputs.Add($"Console.Beep({intfreq}, {intdur});");

									dec %= 1;
								}
								else
								{
									//tra.ce("REST");

									double duration = durationDict[p[0]];

									dec += duration % 1;

									Thread.Sleep((int)duration + (int)dec);
									outputs.Add($"Thread.Sleep({(int)duration + (int)dec});");

									dec %= 1;
								}
							} // end try
							catch (Exception ee)
							{
								if (!(ee is ThreadAbortException))
									MessageBox.Show($"GET OUTTA HERE WITH DAT {ee.GetType().ToString().Split('.').Reverse().ToList()[0]}!!\n\nat note \"{p}\"", "Nope");
							}
						} // end for

						if (delay > 0)
						{
							notes.RemoveRange(0, delay * 4);
							delay = 0;
						}

					} while (crep.Checked); // end do
				}); // end thread

				threads.Add(beeeeep);
				beeeeep.Start();
			}
			catch (Exception ee)
			{
				MessageBox.Show($"GET OUTTA HERE WITH DAT {formatError(ee)}!!", "Nope");
			}
		}

		public string formatError(Exception ee)
		{
			return ee.GetType().ToString().Split('.').Reverse().ToList()[0];
		}

		public void StopBeeeeeping()
		{
			be.sound.Stop();

			Console.Beep(37, 1);

			foreach (Thread p in threads)
				p.Abort();

			threads.Clear();
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			Music temp = list.SelectedIndex >= 0 ? SearchMusicByName(list.SelectedItem.ToString()) : null;

			if (temp == null ? (txtname.Text != "" || txtscript.Text != "" || txtkey.Text != "" || txtbpm.Text != "")
				: (txtname.Text != temp.name || txtscript.Text != temp.notes || txtkey.Text != temp.key || txtbpm.Text != temp.bpm))
			{
				DialogResult res;
				if ((res = MessageBox.Show($"SAVE CHANGES OF MOOSIC \"{txtname.Text}\" BEFORE LEAVING??", "Wait!", MessageBoxButtons.YesNoCancel)) == DialogResult.Yes || res == DialogResult.Cancel)
				{
					if (res == DialogResult.Cancel || txtname.Text == "")
						e.Cancel = true;

					if (res == DialogResult.Yes)
						bsave_Click(null, null);
				}
			}

			StopBeeeeeping();
		}

		private void onstopclick(object sender, EventArgs e)
		{
			StopBeeeeeping();
		}

		private void list_SelectedIndexChanged(object sender, EventArgs e)
		{
			outputs.Clear();

			if (list.SelectedIndex == -1)
				return;

			Music music = SearchMusicByName(list.SelectedItem.ToString());

			txtname.Text = music.name;
			txtscript.Text = music.notes;
			txtkey.Text = music.key;
			txtbpm.Text = music.bpm;
			txtdelay.Text = music.delay;
			cbdelay.Checked = music.ring;
		}

		public Music SearchMusicByName(string name)
		{
			foreach (Music p in musics)
			{
				if (p.name == name)
					return p;
			}

			return null;
		}

		public string url = @"Data.txt";

		public void SaveBeeeeeeeeeeps()
		{
			if (!File.Exists(url))
				File.CreateText(url).Close();

			List<string> data = new List<string>();

			foreach (Music p in musics)
			{
				data.Add(p.name);
				data.Add($"{p.key} {p.bpm}bpm {p.delay}bdelay {p.ring}");
				data.Add(p.notes);
				data.Add("");
			}

			File.WriteAllLines(url, data);
		}

		public void LoadBeeeeeeps()
		{
			musics.Clear();
			list.Items.Clear();

			if (File.Exists(url))
			{
				string[] data = File.ReadAllLines(url);

				Music music = new Music();
				string currentReading = "name";

				string line = "";

				try
				{
					foreach (string p in data)
					{
						line = p;

						if (p == "")
						{
							if (music.name != "")
								musics.Add(music);

							music = new Music();
							currentReading = "name";

							continue;
						}

						switch (currentReading)
						{
							case "name":
								music.name = p;
								currentReading = "key";
								break;
							case "key":
								string[] keyAndBpm = p.Split(' ');
								music.key = keyAndBpm[0];
								music.bpm = keyAndBpm[1].Replace("bpm", "");
								music.delay = keyAndBpm.Length >= 3 ? keyAndBpm[2].Replace("bdelay", "") : "0";
								music.ring = keyAndBpm.Length >= 4 ? bool.Parse(keyAndBpm[3]) : true;
								currentReading = "notes";
								break;
							case "notes":
								music.notes = p;
								currentReading = "get outta here!";
								break;
							default:
								throw new FormatException("aoeuaosentuhasoetuh");
						}
					}
				}
				catch (Exception ee)
				{
					MessageBox.Show($"GET OUTTA HERE WITH DAT {formatError(ee)} AT LINE\n\"{line}\"!!!", "Data Error!");

					return;
				}

				if (music.name != "" && !musics.Contains(music))
					musics.Add(music);

				//tra.ce(musics[1].notes);
			}
			else
			{
				musics.Add(new Music("HELLO!!", "1+. 1g 5 4d 1+ 5d.", "Eb5", "120"));
			}

			foreach (Music p in musics)
				list.Items.Add(p.name);
		}

		private void btnhelp_Click(object sender, EventArgs e)
		{
			string s = "    • Spaces separate notes. In every note, 1~7 indicate do~ti (tones in key), 1- thru 7- mean lower notes, 1+ thru 7+ mean upper notes. A note can be followed by a '#' or a 'b' sign.";
			s += "\n    • For note types, 'o' means a whole note, 'd' means a half note, nothing means a quarter note, 'g' means an 8th note, and 'j' means a 16th note. A dot (.) followed by a note means a dotted note.";
			s += "\n    • For rests, '/' means a quarter rest, ''' (single quote) means an 8th rest, and '\"' (double quote) means a 16th rest.";
			s += "\n    • '~' connects 2 notes. For example, 1o~o lasts a Do for 8 beats (two whole notes).";
			s += "\n\n    • Hotkeys: Help(F1), Save(Ctrl+S), New(Ctrl+N), Play(Enter), Stop(Esc)";
			s += "\n\n•••Asianboii and Nate made this awesome program!!!•••";
			MessageBox.Show(s, "HELP!!!");
		}

		private void btnnew_Click(object sender, EventArgs e)
		{
			txtname.Text = "";
			txtscript.Text = "";
			txtkey.Text = "C5";
			txtbpm.Text = "120";
			txtdelay.Text = "0";
			cbdelay.Checked = true;

			list.SelectedIndex = -1;

			txtscript.Select();
		}

		private void bsave_Click(object sender, EventArgs e)
		{
			if (txtname.Text == "")
			{
				MessageBox.Show("GET OUTTA WITH DAT MUSIC'S NAME!!!", "Err404");

				return;
			}
			Music ddd = SearchMusicByName(txtname.Text.ToString());
			if (ddd != null)
			{
				ddd.name = txtname.Text;
				ddd.notes = txtscript.Text;
				ddd.key = txtkey.Text;
				ddd.bpm = txtbpm.Text;
				ddd.delay = txtdelay.Text;
				ddd.ring = cbdelay.Checked;

				return;
			}
			musics.Add(new Music(txtname.Text, txtscript.Text, txtkey.Text, txtbpm.Text));
			list.Items.Add(txtname.Text);

			SaveBeeeeeeeeeeps();
		}

		private void bdel_Click(object sender, EventArgs e)
		{
			if (list.SelectedIndex == -1)
			{
				MessageBox.Show("PLZ SELECT WHATCHA WANNA DELETE!", "Hey");

				return;
			}

			if (MessageBox.Show($"RU SURE YOU WANNA DELETE \"{list.SelectedItem}\"??", "DontDeleteThisStefan", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				musics.Remove(SearchMusicByName(list.SelectedItem.ToString()));
				list.Items.Remove(list.SelectedItem);

				SaveBeeeeeeeeeeps();
			}
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			switch (keyData)
			{
				case Keys.Control | Keys.S:
					bsave_Click(null, null);
					return true;
				case Keys.F1:
					btnhelp_Click(null, null);
					return true;
				case Keys.Control | Keys.N:
					btnnew_Click(null, null);
					return true;
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		private void list_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Back)
				bdel_Click(null, null);
		}

		private void onoutput(object sender, EventArgs e)
		{
			if (outputs.Count == 0)
			{
				MessageBox.Show("YOU NEED TO PLAY THE MUSIC FIRST!", "Output");

				return;
			}

			Clipboard.SetText(string.Join("\r\n", outputs));

			MessageBox.Show("THE CODE OF THIS MOOOSIC HAS BEEN COPIED TO YOUR CLIPBOARD!", "Gratts!");
		}

		private void bref_Click(object sender, EventArgs e)
		{
			LoadBeeeeeeps();
		}

		private void cbpot_CheckedChanged(object sender, EventArgs e)
		{
			TopMost = cbpot.Checked;
		}

	}

}

public class be
{
	static public SoundPlayer sound = new SoundPlayer();
	static public void ep(double freq, int dur)
	{
		double A = ((500 * (System.Math.Pow(2, 15))) / 1000) - 1;
		double DeltaFT = 2 * Math.PI * freq / 44100.0;

		int Samples = 441 * dur / 10;
		int Bytes = Samples * 4;
		int[] Hdr = { 0X46464952, 36 + Bytes, 0X45564157, 0X20746D66, 16, 0X20001, 44100, 176400, 0X100004, 0X61746164, Bytes };
		using (MemoryStream MS = new MemoryStream(44 + Bytes))
		{
			using (BinaryWriter BW = new BinaryWriter(MS))
			{
				for (int I = 0; I < Hdr.Length; I++)
				{
					BW.Write(Hdr[I]);
				}
				for (int T = 0; T < Samples; T++)
				{
					short Sample = System.Convert.ToInt16(A * Math.Sin(DeltaFT * T));
					BW.Write(Sample);
					BW.Write(Sample);
				}
				BW.Flush();
				MS.Seek(0, SeekOrigin.Begin);

				sound.Stream = MS;
				sound.Play();
			}
		}
	}
}