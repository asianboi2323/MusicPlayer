﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace musicPlayer
{
	public class Music
	{
		public Music(string name = "", string notes = "", string key = "", string bpm = "", string delay = "", bool ring = true)
		{
			this.name = name;
			this.notes = notes;
			this.key = key;
			this.bpm = bpm;
			this.delay = delay;
			this.ring = ring;
		}

		public string name;
		public string notes;
		public string key;
		public string bpm;
		public string delay;
		public bool ring;
	}
}
